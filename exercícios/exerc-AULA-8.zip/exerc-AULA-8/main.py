from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

app = FastAPI()
templates = Jinja2Templates(directory="templates")

estado = {
    "likes": 0,
    "abas": ["curtidas", "jupiter", "professor"],
    "aba_atual": 0
}

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    estado["aba_atual"] = 0
    return templates.TemplateResponse(request, "index.html", {"aba": estado["abas"][0], "likes": estado["likes"]})



@app.get("/abas/{nome}", response_class=HTMLResponse)
async def carregar_aba(request: Request, nome: str):
    
    if nome in estado["abas"]:
        estado["aba_atual"] = estado["abas"].index(nome)
    else:
        nome = "curtidas"
    
    contexto = {"request": request, "aba": nome, "likes": estado["likes"]}
    
    # se o request veio da barra de enderecos (nao htmx), carrega tudo
    if "hx-request" not in request.headers:
        return templates.TemplateResponse(request, "index.html", contexto)
        
    # via htmx retorna apenas a nav e a main para atualizar o botao ativo
    return templates.TemplateResponse(request, "conteudo.html", contexto)



@app.get("/proxima-aba", response_class=HTMLResponse)
async def proxima_aba(request: Request):
    estado["aba_atual"] = (estado["aba_atual"] + 1) % len(estado["abas"])
    nome = estado["abas"][estado["aba_atual"]]
    
    contexto = {"request": request, "aba": nome, "likes": estado["likes"]}
    resposta = templates.TemplateResponse(request, "conteudo.html", contexto)
    

    resposta.headers["HX-Push-Url"] = f"/abas/{nome}"
    return resposta



@app.post("/curtir", response_class=HTMLResponse)
async def curtir(request: Request):
    estado["likes"] += 1
    return templates.TemplateResponse(request, "contador.html", {"likes": estado["likes"]})

@app.delete("/curtir", response_class=HTMLResponse)
async def zerar(request: Request):
    estado["likes"] = 0

    return templates.TemplateResponse(request, "contador.html", {"likes": estado["likes"]})
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

app = FastAPI()

# banco de dados temporario em memoria
usuarios_db = []

# validacao de dados vindos do frontend
class Usuario(BaseModel):
    nome: str
    idade: int

@app.get('/', response_class=HTMLResponse)
async def index():
    # le o html para servir na rota raiz
    with open("index.html", "r", encoding="utf-8") as f:
        html_content = f.read()
    return html_content

@app.post('/users')
async def adicionar_usuario(user: Usuario):
    # adiciona como dicionario e retorna a lista atualizada
    usuarios_db.append(user.model_dump())
    return usuarios_db

@app.get('/users')
async def ler_usuarios(index: int | None = None):
    # verifica se passou query parameter index
    if index is not None:
        if 0 <= index < len(usuarios_db):
            return usuarios_db[index]
        return {"erro": "indice nao encontrado"}
    
    # sem query parameter, retorna tudo
    return usuarios_db

@app.delete('/users')
async def deletar_usuarios():
    # esvazia a lista e retorna ela vazia
    usuarios_db.clear()
    return usuarios_db
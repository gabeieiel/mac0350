from fastapi import FastAPI, Request, Response, Depends, HTTPException, status, Cookie
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import Annotated

app = FastAPI()

# motor de templates
templates = Jinja2Templates(directory="templates")

# validacao de entrada
class Usuario(BaseModel):
    nome: str
    senha: str
    bio: str

class LoginRequest(BaseModel):
    nome: str
    senha: str

# bd em memoria
usuarios_db = []

# dependencia para checar cookie
def get_active_user(session_user: Annotated[str | None, Cookie()] = None):
    if not session_user:    # sem cookie
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="nao logado"
        )
    
    # busca no bd
    user = next((u for u in usuarios_db if u["nome"] == session_user), None)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="sessao invalida")
    
    return user

### GET ###

@app.get("/")
def pagina_cadastro(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")

@app.get("/login")
def pagina_login(request: Request):
    return templates.TemplateResponse(request=request, name="login.html")

@app.get("/perfil")
def pagina_perfil(request: Request, user: dict = Depends(get_active_user)):
    return templates.TemplateResponse(
        request=request, 
        name="perfil.html", 
        context={"user": user}
    )


### POST ###

@app.post("/users", status_code=status.HTTP_201_CREATED)
def criar_usuario(user: Usuario):
    # evita nomes duplicados
    if any(u["nome"] == user.nome for u in usuarios_db):
        raise HTTPException(status_code=400, detail="usuario existente")
    
    usuarios_db.append(user.model_dump())
    return {"message": "criado com sucesso"}

@app.post("/auth")
def autenticar(login_data: LoginRequest, response: Response):
    user = next((u for u in usuarios_db if u["nome"] == login_data.nome), None)
    
    if not user or user["senha"] != login_data.senha:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="senha ou usuario incorretos")
    
    # grava cookie
    response.set_cookie(key="session_user", value=user["nome"])
    return {"message": "logado"}

@app.post("/logout")
def logout(response: Response):
    # deleta cookie
    response.delete_cookie("session_user")
    return {"message": "deslogado"}
from typing import List
from sqlmodel import Field, Relationship, SQLModel

class Aluno(SQLModel, table=True):
    nusp: int | None = Field(default=None, primary_key=True)
    
    nome: str
    idade: int
    
    # o relacionamento.
    # como um aluno tem varias tarefas, definimos como list[tarefa].
    tarefas: List["Tarefa"] = Relationship(back_populates="aluno")


class Tarefa(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    nome: str
    duracao: int
    
    # chave estrangeira referenciando a primary_key do aluno
    aluno_nusp: int = Field(foreign_key="aluno.nusp")

    # o relacionamento de volta -> uma tarefa pertence a um aluno.
    aluno: Aluno = Relationship(back_populates="tarefas")
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from models import Aluno
from contextlib import asynccontextmanager
from sqlmodel import SQLModel, create_engine, Session, select, col

# configuracao padrao da aula
arquivo_sqlite = "HTMX2.db"
url_sqlite = f"sqlite:///{arquivo_sqlite}"
engine = create_engine(url_sqlite, connect_args={"check_same_thread": False})
templates = Jinja2Templates(directory=["Templates", "Templates/Partials"])

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

@asynccontextmanager
async def initFunction(app: FastAPI):
    create_db_and_tables()
    yield

app = FastAPI(lifespan=initFunction)


app.mount("/Static", StaticFiles(directory="Static"), name="static")


# paginacao embutida (limit e offset)
def buscar_alunos(busca: str, pagina: int = 1, limite: int = 5):
    with Session(engine) as session:
        query_base = select(Aluno).where(col(Aluno.nome).contains(busca)).order_by(Aluno.nome)
        
        # conta o total para as paginas
        total_alunos = len(session.exec(query_base).all())
        
        # corta
        offset = (pagina - 1) * limite
        query_paginada = query_base.offset(offset).limit(limite)
        
        return session.exec(query_paginada).all(), total_alunos


@app.get("/busca", response_class=HTMLResponse)
def busca(request: Request):
    return templates.TemplateResponse(request, "index.html")



@app.get("/lista", response_class=HTMLResponse)
def lista(request: Request, busca: str | None = '', pagina: int = 1):
    if busca is None:
        busca = ''
        
    limite = 5
    alunos, total = buscar_alunos(busca, pagina, limite)
    
    # total de paginas
    total_paginas = (total + limite - 1) // limite
    if total_paginas < 1:
        total_paginas = 1
        
    contexto = {
        "alunos": alunos,
        "busca": busca,
        "pagina": pagina,
        "total_paginas": total_paginas
    }
    return templates.TemplateResponse(request, "lista.html", contexto)

@app.get("/editarAlunos")
def novoAluno(request: Request):
    return templates.TemplateResponse(request, "options.html")

@app.post("/novoAluno", response_class=HTMLResponse)
def criar_aluno(nome: str = Form(...)):
    with Session(engine) as session:
        novo_aluno = Aluno(nome=nome)
        session.add(novo_aluno)
        session.commit()
        session.refresh(novo_aluno)
        return HTMLResponse(content=f"<p>O(a) aluno(a) {novo_aluno.nome} foi registrado(a)!</p>")

@app.delete("/deletaAluno", response_class=HTMLResponse)
def deletar_aluno(id: int):
    with Session(engine) as session:
        query = select(Aluno).where(Aluno.id == id)
        aluno = session.exec(query).first()
        if (not aluno):
            raise HTTPException(404, "Aluno não encontrado")
        session.delete(aluno)
        session.commit()
        return HTMLResponse(content=f"<p>O(a) aluno(a) {aluno.nome} foi deletado(a)!</p>")

@app.put("/atualizaAluno", response_class=HTMLResponse)
def atualizar_aluno(id: int = Form(...), novoNome: str = Form(...)):
    with Session(engine) as session:
        query = select(Aluno).where(Aluno.id == id)
        aluno = session.exec(query).first()
        if (not aluno):
            raise HTTPException(404, "Aluno não encontrado")
        nomeAntigo = aluno.nome
        aluno.nome = novoNome
        session.commit()
        session.refresh(aluno)
        return HTMLResponse(content=f"<p>O(a) aluno(a) {nomeAntigo} foi atualizado(a) para {aluno.nome}!</p>")

@app.delete("/apagar", response_class=HTMLResponse)
def apagar():
    return ""